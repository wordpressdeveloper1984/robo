export class Product {
   productName: string;
   quantity: number;
   costPrice: number;
   sellingPrice: number;
}

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema
let Products = new Schema({
   productName: {
      type: String
   },
   quantity: {
      type: Number
   },
   costPrice: {
      type: Number
   },
   sellingPrice: {
      type: Number
   }
}, {
   collection: 'products'
})

module.exports = mongoose.model('products', Products)
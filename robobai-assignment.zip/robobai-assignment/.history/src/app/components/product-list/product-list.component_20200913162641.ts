import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../service/api.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  Products: any = [];

  constructor(private apiService: ApiService) {
    this.readProduct();
  }

  ngOnInit() {}

  readProduct(){
    this.apiService.getProducts().subscribe((data) => {
     this.Products = data;
    });
  }

  removeProduct(employee, index) {
    if (window.confirm('Are you sure?')) {
        this.apiService.deleteEmployee(employee._id).subscribe((data) => {
          this.Products.splice(index, 1);
        }
      );
    }
  }

}

import { Router } from '@angular/router';
import { ApiService } from './../../service/api.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.scss']
})
export class ProductCreateComponent implements OnInit {
  submitted = false;
  productForm: FormGroup;

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private apiService: ApiService
  ) {
    this.mainForm();
  }

  ngOnInit() { }

  mainForm() {
    this.productForm = this.fb.group({
      productName: ['', [Validators.required]],
      quantity: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      costPrice: ['', [Validators.required]],
      sellingPrice: ['', [Validators.required, Validators.pattern('^[0-9]+$')]]
    });
  }

  // Choose designation with select dropdown
  updateProfile(e){
    this.productForm.get('designation').setValue(e, {
      onlySelf: true
    });
  }

  // Getter to access form control
  get myForm(){
    return this.productForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (!this.productForm.valid) {
      return false;
    } else {
      this.apiService.createEmployee(this.productForm.value).subscribe(
        (res) => {
          console.log('Product successfully Added!');
          this.ngZone.run(() => this.router.navigateByUrl('/product-list'));
        }, (error) => {
          console.log(error);
        });
    }
  }

}
